# Ask

## Introduction

>Welcome to the Ask forum –  Design Help Desk, Support, Forum, Knowledge-Base Responsive Site Template. The Ask is a bootstrap design help desk, support forum website template coded and designed with bootstrap Design, Bootstrap, HTML5 and CSS. Ask ideal for wiki sites, knowledge base sites, support forum sites, ticket systems, theme documentations and similar projects. Ask comes with valid HTML files, 100% responsive layout and with clean codes.<br>

#features & Pages:

✔Login<br> 
✔Contact<br> 
✔Forum<br> 
✔Post Details<br> 
✔User<br> 
✔User Question<br> 
✔Category<br>
✔Searching<br>
✔Recent Question<br>
✔Most Response<br>



#�Main features:

✔HTML5 & CSS3<br> 
✔Pixel Perfect Design<br> 
✔Responsive Design<br> 
✔User Friendly Code<br> 
✔Clean Markup<br> 
✔Creative Design<br> 
✔Cross Browser Support<br> 
✔Powered With Bootstrap 4<br> 
✔Used font awesome icon<br> 
✔Google Font<br> 
✔Google Map<br> 
✔Fast Page Loading<br> 
✔Easy to customize<br>  
✔W3C Validated Code<br>   
✔And Much More!<br>


#�Source & Credits
BootStrap 4<br> 
Google font<br> 
Javascript<br> 
Jquery Library<br>
Font Awesome 5<br>


